# 55Five Analytics Dashboard

Dashboard analisis data angka real-time dengan prediksi tren, autentikasi, dan visualisasi.

---

## 📁 Struktur Folder

```
55five-app/
├── public/
│   └── index.html       ← Frontend lengkap
├── server.js            ← Backend Express (proxy API)
├── package.json
├── .env.example
└── README.md
```

---

## ⚡ Install & Jalankan (Lokal)

### 1. Install Node.js
Download dari https://nodejs.org (versi 18+)

### 2. Install dependencies
```bash
cd 55five-app
npm install
```

### 3. Setup Supabase (lihat bagian bawah)

### 4. Jalankan server
```bash
npm start
```

### 5. Buka browser
```
http://localhost:3000
```

---

## 🗄️ Setup Supabase

### Langkah 1 — Buat Project
1. Buka https://supabase.com
2. Klik "New Project"
3. Isi nama project, password database, pilih region
4. Tunggu hingga siap (~2 menit)

### Langkah 2 — Buat Tabel
Buka **SQL Editor** di Supabase, jalankan query ini:

```sql
-- Tabel history per user
CREATE TABLE history (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  issue_number TEXT NOT NULL,
  number INTEGER NOT NULL,
  besar_kecil TEXT NOT NULL,
  fetched_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(issue_number, user_id)
);

-- Row Level Security
ALTER TABLE history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own history"
  ON history FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own history"
  ON history FOR INSERT
  WITH CHECK (auth.uid() = user_id);
```

### Langkah 3 — Ambil Kredensial
1. Buka **Settings → API**
2. Copy **Project URL** → `SUPABASE_URL`
3. Copy **anon public key** → `SUPABASE_KEY`

### Langkah 4 — Isi di index.html
Buka `public/index.html`, cari baris:
```js
const SUPABASE_URL = 'https://YOUR_PROJECT.supabase.co';
const SUPABASE_KEY = 'YOUR_ANON_KEY';
```
Ganti dengan nilai Anda.

---

## ☁️ Deploy ke Render (Gratis)

### 1. Upload ke GitHub
```bash
git init
git add .
git commit -m "init"
git remote add origin https://github.com/USERNAME/55five-app.git
git push -u origin main
```

### 2. Buka https://render.com
1. Klik **New → Web Service**
2. Connect repository GitHub Anda
3. Isi:
   - **Name**: 55five-tracker
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
4. Klik **Create Web Service**
5. Tunggu deploy (~3 menit)
6. Buka URL yang diberikan Render

---

## ☁️ Deploy ke Vercel

```bash
npm install -g vercel
vercel
```

Tambahkan `vercel.json`:
```json
{
  "version": 2,
  "builds": [{ "src": "server.js", "use": "@vercel/node" }],
  "routes": [{ "src": "/(.*)", "dest": "server.js" }]
}
```

---

## 🔐 Fitur Auth

| Fitur | Status |
|-------|--------|
| Register email/password | ✅ |
| Login | ✅ |
| Logout | ✅ |
| Auto session restore | ✅ |
| Demo mode (tanpa akun) | ✅ |
| Simpan history per user | ✅ |

---

## 📊 Fitur Analisis

| Fitur | Keterangan |
|-------|------------|
| Prediksi Besar/Kecil | Berdasarkan streak + moving avg + distribusi |
| Confidence % | 50–82% |
| Streak detection | Deteksi berturut-turut |
| Moving average (5 & 10) | Rata-rata bergerak |
| Distribusi | % Besar vs Kecil |
| Frekuensi per angka | 0–9 |
| Win rate prediksi | Tracking akurasi historis |
| Grafik real-time | Chart.js line chart |
| Auto refresh | Setiap 5 detik |

---

## ⚠️ Catatan

- API eksternal (55fiveapi.com) mungkin memerlukan autentikasi tambahan
- Jika API gagal, sistem otomatis menggunakan data fallback/demo
- Semua data tersimpan di localStorage sebagai backup
